var e={production:!0,useHash:!1,api:{baseUrl:"/api",refreshTokenEnabled:!1,refreshTokenType:"auth-refresh"}};export{e as a};
